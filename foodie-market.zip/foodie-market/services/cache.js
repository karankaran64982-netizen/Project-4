// Task 8: server-side caching for expensive/external calls
const NodeCache = require('node-cache');
const cache = new NodeCache({ stdTTL: 300, checkperiod: 60 });
module.exports = { cache };
