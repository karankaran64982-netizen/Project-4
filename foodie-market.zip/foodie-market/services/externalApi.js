// Task 7: integrating a third-party external API, with graceful fallback
// and error handling if the external service is unreachable.
const fetch = require('node-fetch');

async function fetchExternalDeals() {
  try {
    const res = await fetch('https://fakestoreapi.com/products?limit=4', { timeout: 5000 });
    if (!res.ok) throw new Error('Bad response from external API');
    const data = await res.json();
    return data.map(item => ({
      id: item.id,
      title: item.title,
      price: item.price,
      image: item.image
    }));
  } catch (err) {
    console.warn('External API unavailable, using fallback deals:', err.message);
    return [
      { id: 'fallback-1', title: 'Seasonal Fruit Basket', price: 12.99, image: '/images/placeholder.svg' },
      { id: 'fallback-2', title: 'Artisan Bread Loaf', price: 4.5, image: '/images/placeholder.svg' },
      { id: 'fallback-3', title: 'Cold Brew Coffee Pack', price: 8.25, image: '/images/placeholder.svg' },
      { id: 'fallback-4', title: 'Organic Veggie Box', price: 15.0, image: '/images/placeholder.svg' }
    ];
  }
}

module.exports = { fetchExternalDeals };
