// Task 8: background job / task queue simulation (stand-in for Redis + a worker).
// Orders are enqueued at checkout and "processed" asynchronously rather than inline.
const { readJSON, writeJSON } = require('../config/db');

const queue = [];
let processing = false;

function enqueue(orderId) {
  queue.push(orderId);
  console.log(`[jobQueue] Order ${orderId} queued for processing`);
  processQueue();
}

function processQueue() {
  if (processing || queue.length === 0) return;
  processing = true;
  const orderId = queue.shift();

  // Simulate async background work (payment capture, inventory update, email, etc.)
  setTimeout(() => {
    const orders = readJSON('orders.json');
    const order = orders.find(o => o.id === orderId);
    if (order) {
      order.status = 'processed';
      writeJSON('orders.json', orders);
      console.log(`[jobQueue] Order ${orderId} processed`);
    }
    processing = false;
    processQueue();
  }, 2000);
}

module.exports = { enqueue };
