// Task 1/3/5: server-rendered pages (EJS), product browsing, cart, checkout, admin UI
const express = require('express');
const { readJSON, writeJSON } = require('../config/db');
const { requireLogin, requireAdmin } = require('../middleware/auth');
const { cache } = require('../services/cache');
const { fetchExternalDeals } = require('../services/externalApi');
const { enqueue } = require('../services/jobQueue');

const router = express.Router();

router.get('/', async (req, res) => {
  const products = readJSON('products.json');
  const featured = products.slice(0, 6);

  let deals = cache.get('external-deals');
  if (!deals) {
    deals = await fetchExternalDeals();
    cache.set('external-deals', deals, 300); // 5 minute cache
  }
  res.render('index', { title: 'Foodie Market', featured, deals });
});

router.get('/products', (req, res) => {
  const products = readJSON('products.json');
  const { category, q } = req.query;
  let filtered = products;
  if (category) filtered = filtered.filter(p => p.category === category);
  if (q) filtered = filtered.filter(p => p.name.toLowerCase().includes(q.toLowerCase()));
  const categories = [...new Set(products.map(p => p.category))];
  res.render('products', { title: 'Shop', products: filtered, categories, activeCategory: category || '', q: q || '' });
});

router.get('/products/:id', (req, res) => {
  const products = readJSON('products.json');
  const product = products.find(p => p.id === req.params.id);
  if (!product) return res.status(404).render('404', { title: 'Not Found' });
  res.render('product-detail', { title: product.name, product });
});

router.post('/cart/add', (req, res) => {
  const { productId, quantity } = req.body;
  const products = readJSON('products.json');
  const product = products.find(p => p.id === productId);
  if (!product) return res.redirect('/products');

  const qty = Math.max(1, parseInt(quantity, 10) || 1);
  const cart = req.session.cart || [];
  const existing = cart.find(i => i.productId === productId);
  if (existing) existing.quantity += qty;
  else cart.push({ productId, name: product.name, price: product.price, quantity: qty });
  req.session.cart = cart;
  res.redirect('/cart');
});

router.post('/cart/update', (req, res) => {
  const { productId, quantity } = req.body;
  const cart = req.session.cart || [];
  const item = cart.find(i => i.productId === productId);
  if (item) item.quantity = Math.max(0, parseInt(quantity, 10) || 0);
  req.session.cart = cart.filter(i => i.quantity > 0);
  res.redirect('/cart');
});

router.post('/cart/remove', (req, res) => {
  const { productId } = req.body;
  req.session.cart = (req.session.cart || []).filter(i => i.productId !== productId);
  res.redirect('/cart');
});

router.get('/cart', (req, res) => {
  const cart = req.session.cart || [];
  const total = cart.reduce((sum, i) => sum + i.price * i.quantity, 0);
  res.render('cart', { title: 'Your Cart', cart, total });
});

router.get('/checkout', requireLogin, (req, res) => {
  const cart = req.session.cart || [];
  if (cart.length === 0) return res.redirect('/cart');
  const total = cart.reduce((sum, i) => sum + i.price * i.quantity, 0);
  res.render('checkout', { title: 'Checkout', cart, total });
});

router.post('/checkout', requireLogin, (req, res) => {
  const cart = req.session.cart || [];
  if (cart.length === 0) return res.redirect('/cart');

  const orders = readJSON('orders.json');
  const order = {
    id: Date.now().toString(),
    userId: req.session.user.id,
    items: cart,
    total: cart.reduce((sum, i) => sum + i.price * i.quantity, 0),
    status: 'queued',
    createdAt: new Date().toISOString()
  };
  orders.push(order);
  writeJSON('orders.json', orders);

  enqueue(order.id); // background job processes the order asynchronously

  req.session.cart = [];
  res.render('order-confirmation', { title: 'Order Confirmed', order });
});

router.get('/admin', requireLogin, requireAdmin, (req, res) => {
  const products = readJSON('products.json');
  const orders = readJSON('orders.json');
  const users = readJSON('users.json');
  res.render('admin/dashboard', { title: 'Admin Dashboard', products, orders, users });
});

module.exports = router;
