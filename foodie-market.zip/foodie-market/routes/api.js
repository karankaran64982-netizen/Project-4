// Task 5/6/7: RESTful CRUD API, protected admin endpoints, external API passthrough
const express = require('express');
const { readJSON, writeJSON } = require('../config/db');
const { apiAuth, apiAdmin } = require('../middleware/auth');
const { productRules, handleValidation } = require('../middleware/validate');
const { fetchExternalDeals } = require('../services/externalApi');

const router = express.Router();

// GET all products (supports ?category=&q=)
router.get('/products', (req, res) => {
  const products = readJSON('products.json');
  const { category, q } = req.query;
  let filtered = products;
  if (category) filtered = filtered.filter(p => p.category === category);
  if (q) filtered = filtered.filter(p => p.name.toLowerCase().includes(q.toLowerCase()));
  res.json(filtered);
});

router.get('/products/:id', (req, res) => {
  const products = readJSON('products.json');
  const product = products.find(p => p.id === req.params.id);
  if (!product) return res.status(404).json({ error: 'Product not found' });
  res.json(product);
});

router.post('/products', apiAuth, apiAdmin, productRules, handleValidation, (req, res) => {
  const products = readJSON('products.json');
  const newProduct = {
    id: Date.now().toString(),
    name: req.body.name,
    price: parseFloat(req.body.price),
    category: req.body.category,
    stock: parseInt(req.body.stock, 10),
    description: req.body.description || '',
    image: req.body.image || '/images/placeholder.svg'
  };
  products.push(newProduct);
  writeJSON('products.json', products);
  res.status(201).json(newProduct);
});

router.put('/products/:id', apiAuth, apiAdmin, productRules, handleValidation, (req, res) => {
  const products = readJSON('products.json');
  const idx = products.findIndex(p => p.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Product not found' });
  products[idx] = {
    ...products[idx],
    ...req.body,
    price: parseFloat(req.body.price),
    stock: parseInt(req.body.stock, 10)
  };
  writeJSON('products.json', products);
  res.json(products[idx]);
});

router.delete('/products/:id', apiAuth, apiAdmin, (req, res) => {
  const products = readJSON('products.json');
  const filtered = products.filter(p => p.id !== req.params.id);
  if (filtered.length === products.length) return res.status(404).json({ error: 'Product not found' });
  writeJSON('products.json', filtered);
  res.status(204).end();
});

// Cart as a JSON API (mirrors the session-based page routes)
router.get('/cart', (req, res) => {
  res.json(req.session.cart || []);
});

router.post('/cart', (req, res) => {
  const { productId, quantity } = req.body;
  const products = readJSON('products.json');
  const product = products.find(p => p.id === productId);
  if (!product) return res.status(404).json({ error: 'Product not found' });

  const qty = Math.max(1, parseInt(quantity, 10) || 1);
  const cart = req.session.cart || [];
  const existing = cart.find(i => i.productId === productId);
  if (existing) existing.quantity += qty;
  else cart.push({ productId, name: product.name, price: product.price, quantity: qty });
  req.session.cart = cart;
  res.status(201).json(cart);
});

// Orders (requires auth; admins see all, customers see their own)
router.get('/orders', apiAuth, (req, res) => {
  const orders = readJSON('orders.json');
  const mine = req.user.role === 'admin' ? orders : orders.filter(o => o.userId === req.user.id);
  res.json(mine);
});

// Task 7: external API integration example
router.get('/external/deals', async (req, res) => {
  try {
    const deals = await fetchExternalDeals();
    res.json(deals);
  } catch (err) {
    res.status(502).json({ error: 'External service unavailable' });
  }
});

module.exports = router;
