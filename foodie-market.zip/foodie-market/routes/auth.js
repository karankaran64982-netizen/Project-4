// Task 2/6: registration, login, logout, and JWT token issuance
const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { readJSON, writeJSON } = require('../config/db');
const { registerRules, loginRules, handleValidation } = require('../middleware/validate');
const { JWT_SECRET } = require('../middleware/auth');

const router = express.Router();

router.get('/register', (req, res) => {
  const errors = req.session.formErrors || [];
  const old = req.session.formData || {};
  req.session.formErrors = null;
  req.session.formData = null;
  res.render('register', { title: 'Create Account', errors, old });
});

router.post('/register', registerRules, handleValidation, (req, res) => {
  const { name, email, password } = req.body;
  const users = readJSON('users.json');

  if (users.find(u => u.email === email)) {
    req.session.formErrors = [{ msg: 'An account with that email already exists' }];
    req.session.formData = req.body;
    return res.redirect('/auth/register');
  }

  const hashed = bcrypt.hashSync(password, 10);
  const newUser = {
    id: Date.now().toString(),
    name,
    email,
    password: hashed,
    role: users.length === 0 ? 'admin' : 'customer', // first registered user becomes admin
    createdAt: new Date().toISOString()
  };
  users.push(newUser);
  writeJSON('users.json', users);

  req.session.user = { id: newUser.id, name: newUser.name, email: newUser.email, role: newUser.role };
  res.redirect('/');
});

router.get('/login', (req, res) => {
  const errors = req.session.formErrors || [];
  req.session.formErrors = null;
  res.render('login', { title: 'Login', errors, next: req.query.next || '/' });
});

router.post('/login', loginRules, handleValidation, (req, res) => {
  const { email, password } = req.body;
  const users = readJSON('users.json');
  const user = users.find(u => u.email === email);

  if (!user || !bcrypt.compareSync(password, user.password)) {
    req.session.formErrors = [{ msg: 'Invalid email or password' }];
    return res.redirect('/auth/login');
  }

  req.session.user = { id: user.id, name: user.name, email: user.email, role: user.role };
  res.redirect(req.body.next || '/');
});

router.post('/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/'));
});

// Task 7: token-based auth endpoint for external/API clients (OAuth-style bearer token)
router.post('/token', (req, res) => {
  const { email, password } = req.body;
  const users = readJSON('users.json');
  const user = users.find(u => u.email === email);
  if (!user || !bcrypt.compareSync(password, user.password)) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }
  const token = jwt.sign({ id: user.id, name: user.name, role: user.role }, JWT_SECRET, { expiresIn: '2h' });
  res.json({ token });
});

module.exports = router;
