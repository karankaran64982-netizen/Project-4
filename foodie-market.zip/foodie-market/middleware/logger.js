// Task 8: middleware for request processing/logging
const fs = require('fs');
const path = require('path');

const logFile = path.join(__dirname, '..', 'data', 'requests.log');

function requestLogger(req, res, next) {
  const line = `[${new Date().toISOString()}] ${req.method} ${req.originalUrl} - ${req.ip}\n`;
  fs.appendFile(logFile, line, () => {});
  next();
}

module.exports = { requestLogger };
