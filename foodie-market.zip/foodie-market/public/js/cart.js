// Small client-side enhancement layered on top of server-rendered forms.
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('form[action="/cart/remove"]').forEach(form => {
    form.addEventListener('submit', (e) => {
      if (!confirm('Remove this item from your cart?')) e.preventDefault();
    });
  });
});
